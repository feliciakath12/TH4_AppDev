﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Team
{
    public string teamName ;
    public string teamCountry;
    public string teamCity;
    public List<Player> Players;




}

