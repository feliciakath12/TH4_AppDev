﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace W4_Take_Home
{
    public partial class Form1 : Form
    {
        List<Team> listTeam = new List<Team>();
        //List<Player> listPlayer = new List<Player>();
        List<string> listPlayer = new List<string>();
        //List<string> listNumPlayer = new List<string>();
        List<string> listCountry = new List<string>();
        List<string> listNameTeam = new List<string>();
        List<string> listCity = new List<string>();
        //int count = 0;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listCountry.Add("England");
            listNameTeam.Add("Manchester United");
            listNameTeam.Add("Chelsea");

            listCountry.Add("Germany");
            listNameTeam.Add("Munchen");

            listTeam.Add(new Team
            {
                teamCountry = "England",
                teamName = "Manchester United",
                teamCity = "Manchester",
                Players = new List<Player>()
                {
                    new Player{playerName = "David De Gea", playerNum ="1", playerPos = "GK"},
                    new Player{playerName = "Victor Lindelof", playerNum ="2", playerPos = "DF"},
                    new Player{playerName = "Phil Jones", playerNum ="4", playerPos = "DF"},
                    new Player{playerName = "Harry Maguire", playerNum ="5", playerPos = "DF"},
                    new Player{playerName = "Lisandro Martinez", playerNum ="6", playerPos = "DF"},
                    new Player{playerName = "Bruno Fernandez", playerNum ="8", playerPos = "MF"},
                    new Player{playerName = "Anthony Martial", playerNum ="9", playerPos = "FW"},
                    new Player{playerName = "Marcus Rashford", playerNum ="10", playerPos = "FW"},
                    new Player{playerName = "Tyrell Malacia", playerNum ="12", playerPos = "DF"},
                    new Player{playerName = "Christian Eriksen", playerNum ="14", playerPos = "MF"},
                    new Player{playerName = "Casemiro", playerNum ="18", playerPos = "MF"}
                }
            }) ;


            listTeam.Add(new Team
            {
                teamCountry = "England",
                teamName = "Chelsea",
                teamCity = "London",
                Players = new List<Player>()
                {
                    new Player{playerName = "Kepa Arrizzabalaga", playerNum ="1", playerPos = "GK"},
                    new Player{playerName = "Benoit Badiashile", playerNum ="4", playerPos = "DF"},
                    new Player{playerName = "Enzo Fernandez", playerNum ="5", playerPos = "MF"},
                    new Player{playerName = "Thiago Silva", playerNum ="6", playerPos = "DF"},
                    new Player{playerName = "N'Golo Kante", playerNum ="7", playerPos = "MF"},
                    new Player{playerName = "Mateo Kovacic", playerNum ="8", playerPos = "MF"},
                    new Player{playerName = "Pierre-Emerick Aubameyang", playerNum ="9", playerPos = "FW"},
                    new Player{playerName = "Christian Pulisic", playerNum ="10", playerPos = "MF"},
                    new Player{playerName = "Joao Felix", playerNum ="11", playerPos = "FW"},
                    new Player{playerName = "Ruben Loftus-Cheek", playerNum ="12", playerPos = "MF"},
                    new Player{playerName = "Raheem Sterling", playerNum ="17", playerPos = "MF"},
                }
            });

            listTeam.Add(new Team
            {
                teamCountry = "Germany",
                teamName = "Bayern Munich",
                teamCity = "Munchen",
                Players = new List<Player>()
                {
                    new Player{playerName = "Manuel Neuer", playerNum ="1", playerPos = "GK"},
                    new Player{playerName = "Dayot Upamecano", playerNum ="2", playerPos = "DF"},
                    new Player{playerName = "Matthijs de Ligt", playerNum ="4", playerPos = "DF"},
                    new Player{playerName = "Benjamin Pavard", playerNum ="5", playerPos = "DF"},
                    new Player{playerName = "Joshua Kimmich", playerNum ="6", playerPos = "MF"},
                    new Player{playerName = "Serge Gnarby", playerNum ="7", playerPos = "FW"},
                    new Player{playerName = "Leon Goretzka", playerNum ="8", playerPos = "MF"},
                    new Player{playerName = "Leroy Sane", playerNum ="10", playerPos = "FW"},
                    new Player{playerName = "Paul Wanner", playerNum ="14", playerPos = "MF"},
                    new Player{playerName = "Lucas Hernandez", playerNum ="21", playerPos = "DF"},
                    new Player{playerName = "Thomas Muller", playerNum ="25", playerPos = "FW"},
                }
            });

            cbx_PPosition.Items.Add("GK");
            cbx_PPosition.Items.Add("DF");
            cbx_PPosition.Items.Add("MF");
            cbx_PPosition.Items.Add("FW");

        }

        private void btn_AddT_Click(object sender, EventArgs e)
        {
            if (tb_TName.Text.Length == 0 || tb_TCountry.Text.Length == 0 || tb_TCity.Text.Length == 0)
            {
                MessageBox.Show("All Fields need to be Filled", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                cekCountryKembar();
                cekTimKembar();
            }

            tb_TName.Clear();
            tb_TCountry.Clear();
            tb_TCity.Clear();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            var kepilih = listTeam.Find(Team => Team.teamName == cbx_Team.SelectedItem.ToString());
            if (cbx_Team.SelectedIndex >= 0)
            {
                if (lbx_PlayerList.SelectedItems != null)
                {
                    if (lbx_PlayerList.Items.Count < 12)
                    {
                        MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    else
                    {
                        lbx_PlayerList.Items.RemoveAt(lbx_PlayerList.SelectedIndex);

                        foreach (var timnya in listTeam)
                        {
                            foreach (var player in timnya.Players)
                            {
                                if (lbx_PlayerList.SelectedItems.ToString() == $"({player.playerNum})  {player.playerName}, {player.playerPos}")
                                {
                                    timnya.Players.Remove(player);
                                    break;
                                }
                            }
                        }
                    }
                }
                
            }
        }

        private void btn_AddP_Click(object sender, EventArgs e)
        {
            if (cbx_Team.SelectedIndex >= 0)
            {
                if (tb_PName.Text.Length == 0 || tb_PNumber.Text.Length == 0 || cbx_PPosition.SelectedIndex < 0)
                {
                    MessageBox.Show("All Fields need to be Filled", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    cekPlayersKembar();
                }
                tb_PName.Clear();
                tb_PNumber.Clear();
            }
            else
            {
                MessageBox.Show("Select a Team!", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cekPlayersKembar()
        {
            if (cbx_Team.SelectedIndex >= 0)
            {
                bool cek = false;
                var kepilihtim = listTeam.Find(Team => Team.teamName == cbx_Team.SelectedItem.ToString());

                foreach (var player in kepilihtim.Players)
                {
                    if (tb_PName.Text == player.playerName || tb_PNumber.Text == player.playerNum)
                    {
                        cek = true;
                    }
                }

                if (cek == false)
                {
                    kepilihtim.Players.Add(new Player { playerName = tb_PName.Text, playerNum = tb_PNumber.Text, playerPos = cbx_PPosition.SelectedItem.ToString() });
                    lbx_PlayerList.Items.Clear();
                    foreach (var tampilPlayer in kepilihtim.Players)
                    {
                        lbx_PlayerList.Items.Add("(" + tampilPlayer.playerNum + ") " + tampilPlayer.playerName + ", " + tampilPlayer.playerPos);
                    }

                }
                else if (cek == true)
                {
                    MessageBox.Show("Player with Same Number is Found", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void cbx_Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_Country.SelectedIndex >= 0)
            {
                lbx_PlayerList.Items.Clear();
                cbx_Team.Text = string.Empty;
                var kepilih = listTeam.Where(Team => Team.teamCountry == cbx_Country.SelectedItem.ToString()).ToList();
                cbx_Team.Items.Clear();

                if (kepilih.Count > 0)
                {
                    cbx_Team.Enabled = true;
                    foreach (var team in kepilih)
                    {
                        cbx_Team.Items.Add(team.teamName);
                    }
                }
                else
                {
                    cbx_Team.Enabled = false;
                    lbx_PlayerList.Items.Clear();
                }
            }
        }
        private void cekTimKembar()
        {
            bool cek = false;
            for (int i = 0; i < listTeam.Count(); i++)
            {
                if (tb_TName.Text == listTeam[i].teamName)
                {
                    cek = true;
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == true)
            {
                MessageBox.Show("Team name is already found", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cek == false)
            {
                listTeam.Add(new Team
                {
                    teamCountry = tb_TCountry.Text,
                    teamName = tb_TName.Text,
                    teamCity = tb_TCity.Text,
                    Players = new List<Player>()
                   
                });
                
                listCountry.Add(tb_TCountry.Text);
                listNameTeam.Add(tb_TName.Text);
                listCity.Add(tb_TCity.Text);

            }
        }

        private void cekCountryKembar()
        {
            bool cek = false;
            for (int i = 0; i < listCountry.Count; i++)
            {
                if (tb_TCountry.Text == listCountry[i])
                {
                    cek = true;
                }
            }
            if (cek == false)
            {
                cbx_Country.Items.Add(tb_TCountry.Text);
            }
        }

        private void cbx_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbx_PlayerList.Items.Clear();
            var kepilih = listTeam.Find(Team => Team.teamName == cbx_Team.SelectedItem.ToString());

            foreach (var player in kepilih.Players)
            {
                lbx_PlayerList.Items.Add($"({player.playerNum})  {player.playerName}, {player.playerPos}");
                
            }
        }

    }
}
